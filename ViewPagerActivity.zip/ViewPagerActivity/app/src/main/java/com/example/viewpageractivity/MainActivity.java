package com.example.viewpageractivity;

import android.content.Context;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    ViewPager mViewPager;                                                                           //View Pager
    CustomPagerAdapter mCustomPagerAdapter;                                                         //Adapter for View Pager
    private static SensorManager sSensorManager = null;                                             //Sensor Manager for Activity
    private static Sensor sSensor               = null;                                             //Game_Rotation_Vector
    private static Sensor sGyroscope            = null;                                             //Gyroscope Sensor
    private float SmoothedValue                 = 0f;                                               //Smoothing Value for Motion
    private float prevRotation = 0f;                                                                //Check for Idle State
    private int frameCount                      = 0;                                                //Current Frame Monitor
    private int midOfFrame                      = 0;                                                //Marks the Middle Element/Frame

/*    String[] imageUrls                        = { "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/58649e5a-0dcd-43c9-bebe-a9925245da3b1560922456272-2Shoe-1.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/6a09d248-81af-4ef1-907b-43d7d40f4a3a1560922456253-2Shoe-2.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/9b6d4a5c-ae6d-46d5-abfc-de620a44179c1560922456232-2Shoe-3.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/bb01eb62-22f8-4898-9e0c-c476984b43e01560922456214-2Shoe-4.jpg",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/010529ec-afa8-4c7b-ac52-22074ff8d3351560922456195-2Shoe-5.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/d32d434e-ddaa-47c0-87ab-064ab55b5a3f1560922456171-2Shoe-6.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/a0028078-a5d0-4b83-a6ea-28dd1b480b791560922456148-2Shoe-7.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/37ca52c7-4ee6-4201-aa2c-e83a57ae96221560922456129-2Shoe-8.jpg",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/d7a82957-9aab-4c04-ad4d-c9190fd0cb1c1560922456105-2Shoe-9.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/f0e4c2ec-bcfa-4924-8017-c18fbcd0fbb51560922456080-2Shoe-10.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/3f6b396b-9cd4-48eb-9a21-836aed6103ec1560922456056-2Shoe-11.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/bbc6524f-e9f5-4a6e-94b0-410cef4761d01560922456036-2Shoe-12.jpg",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/d24aa549-ec7b-4ef1-be10-9d2e2126301a1560922500703-2Shoe-13.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/01deccb9-96cd-4c4b-ba80-155230424ec51560922500681-2Shoe-14.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/98ad8ea4-1d4f-4f46-9a37-e511e2806a201560922500663-2Shoe-15.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/a550187a-d88a-4e8e-89d5-6046eb766fb61560922500646-2Shoe-16.jpg",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/4763593f-2f5a-4d10-a65f-d37793dad2681560922500628-2Shoe-17.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/368d2817-9562-45f3-8b96-4db49073c4d51560922500610-2Shoe-18.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/0d6afec3-6c0d-4e0f-8d0f-19527f0e8b371560922500592-2Shoe-19.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/071f02a0-9df5-4c37-966b-a4321839598e1560922500574-2Shoe-20.jpg",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/ff4c2802-432e-4079-940e-825e1db296011560922500555-2Shoe-21.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/9735be6c-1c8f-4916-b4b6-811a8572a6f61560922500539-2Shoe-22.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/04d5adba-a09e-4c08-ba1e-60e6d66dbed71560922500516-2Shoe-23.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/c9f96933-e76d-4fda-a633-9ca4aa4647bd1560922500501-2Shoe-24.jpg",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/1e203882-86ba-467b-b110-32cdeeb5e4a41560922500484-2Shoe-25.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/286990f5-d94e-4f0d-a7fb-3f70325647c81560922500470-2Shoe-26.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/2d2e2480-a60c-4250-ab16-a2c3e6a298c71560922550795-2Shoe-27.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/2befb89c-9e8f-4ca4-970e-bd61d98353b41560922550777-2Shoe-28.jpg",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/2bcb8105-13ee-4f9e-b834-cbb2865816f11560922550759-2Shoe-29.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/e75230eb-082f-4b4d-affb-d87cf087cf4a1560922550743-2Shoe-30.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/51b1fe9f-4771-4b3f-be5c-351612c9817a1560922550724-2Shoe-31.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/aa6068d3-079b-49df-a99e-2496cece11411560922550702-2Shoe-32.jpg",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/c554963a-9d92-4b5d-adb5-730609b8c66a1560922550686-2Shoe-33.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/f0a4e300-8bf9-4728-94d4-33cd9f62bd3c1560922550664-2Shoe-34.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/e8af4c90-d7b0-4f72-8c05-33d1360572f01560922550643-2Shoe-35.jpg", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/19/326a3794-c699-4993-86da-9aa3592392361560922550625-2Shoe-36.jpg" };
*/

    String[] imageUrls                          = { "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/5f8c206a-66ce-409a-9ef0-5a6e50296a3f1561698982353-560A9833.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/8cd5d3eb-1852-46a8-9dc1-3a8ed61303211561698982302-560A9834.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/d3623ebd-c849-4ee7-8599-eed4c7c9b52f1561698982253-560A9835.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/4e10e83a-f7d6-4d0a-a675-c9ac056a1a7d1561698982206-560A9836.webp",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/eacb1521-f5fa-4b39-b524-d884bebeb1f21561698982157-560A9837.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/a80a1a61-74f4-40af-ae53-e5d55ca9bfaa1561698982107-560A9838.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/9837b551-a320-4d22-b959-a7a1210763b51561698982056-560A9839.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/936ed7a2-7961-4653-99e4-cde07c90faeb1561698982013-560A9840.webp",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/9af462d7-dd13-4cf5-9837-0bf1c32c23cf1561698981969-560A9841.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/e2b6c17b-27d5-4b44-81ca-8d3686d7011f1561698981926-560A9842.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/beca0fa1-d14a-47f1-86ca-a6aac8f4e9e21561698981883-560A9843.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/274ebe57-fd66-438f-8e00-6c5b184ab57c1561698981845-560A9844.webp",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/ad96a7e1-ad52-45bc-a953-d693df6682a51561698981790-560A9845.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/fb85dcae-7e5c-4e9f-a8d1-c667f0e8e3451561698981760-560A9846.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/905e72f8-8d3b-46fb-b132-0d23051ece941561698981713-560A9847.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/7dc4aea7-fd73-4e9a-801e-0d68501140e11561699151131-560A9848.webp",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/f93f833f-f829-42f3-9cdf-b2ca89b8683e1561699151070-560A9849.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/d00311e9-4448-4372-96cd-01116d9cfe711561699151035-560A9850.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/d7c66c0b-741b-4af0-a53e-222222e0be251561699150978-560A9851.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/ee38df85-aae0-467d-add3-5e793b631c371561699150927-560A9852.webp",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/e1ecf9e8-09a1-4aff-8b1b-8c1c3f1aaf781561699150877-560A9853.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/9eba26a2-2a12-4445-833c-28f00f180bc81561699150827-560A9854.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/43f5f89e-40c0-411f-9f93-99ffbe5b7d8a1561699150775-560A9855.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/53051549-e59a-4e12-b30c-ce2af7b341d21561699150724-560A9856.webp",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/b3809a52-5069-4c35-9dfc-9e55bc5773dc1561699150674-560A9857.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/d453e87d-c3a7-4b1c-aba7-3c6d64fbb50b1561699150622-560A9858.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/47053caf-450f-4bfb-9867-c628d4966d191561699150572-560A9859.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/29981e08-3ef5-4283-b618-66152301ba911561699150522-560A9860.webp",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/3614b20f-f6b6-4462-bdc2-778dfd9a6cf81561699150469-560A9861.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/fde4a557-922e-4741-a660-d9e973823bbc1561699150427-560A9862.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/072d63b6-96cc-410a-a166-0c3e579d01061561699236732-560A9863.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/b390fdbd-4f8e-4ed7-b69e-a824412f61141561699236698-560A9864.webp",
                                                    "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/52887ac5-f4b8-4545-b0dd-00241b27fcb21561699236645-560A9865.webp", "https://assets.myntassets.com/h_700/w_500/assets/images/retaillabs/2019/6/28/beb0ad49-088d-4e5d-a8ab-672ecdc3f13b1561699236615-560A9866.webp" };

    private int endOfFrame                      = getImageSize();                                   //Marks End of the Frame;
    private float tweakFactor                   = getTweakFactor();                                 //Tweak Factor for Motion

    private float preGyroValue                  = 0f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().getDecorView().setBackgroundColor(Color.WHITE);
        mCustomPagerAdapter = new CustomPagerAdapter(this, imageUrls);
        mViewPager = findViewById(R.id.pager);
        mViewPager.setAdapter(mCustomPagerAdapter);

        sSensorManager = (SensorManager) this.getSystemService(Context.SENSOR_SERVICE);
        sSensor = sSensorManager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        sGyroscope = sSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        findMidFrame(endOfFrame);
        frameCount = midOfFrame;
        mViewPager.setOffscreenPageLimit(midOfFrame);
        mViewPager.setCurrentItem(midOfFrame);
    }


    public int getImageSize()
    {
        return imageUrls.length;
    }


    @Override
    public void onSensorChanged(SensorEvent event) {

        if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            float[] gyroValue   = event.values.clone();
            preGyroValue        = smoothGyro(gyroValue[1] * 50, preGyroValue);
        }


        //Rotation Vector Sensor Event
        else if (event.sensor.getType() == Sensor.TYPE_GAME_ROTATION_VECTOR && (preGyroValue > 20
                || preGyroValue < -20)) {

            float currentRotation = event.values[1];                                                //Y-axis currentRotation
            currentRotation       *= 100;                                                           //Smoothing
            SmoothedValue         = smooth(currentRotation, SmoothedValue);
            currentRotation       = SmoothedValue;
            //Forward Movement
            if (currentRotation - prevRotation > tweakFactor && frameCount + 1 < endOfFrame) {
                frameCount        += 1;                                                             //Frame Incrementing
                mViewPager.setCurrentItem(frameCount,false);
                prevRotation      = currentRotation;
            }

            //Backward Movement
            else if (prevRotation - currentRotation > tweakFactor && frameCount - 1 >= 0) {
                frameCount        -= 1;                                                             //Frame Decrementing
                mViewPager.setCurrentItem(frameCount,false);
                prevRotation      = currentRotation;
            }

        }

    }


    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }


    @Override
    protected void onResume() {
        super.onResume();
        if (deviceSupported()) {
            sSensorManager.registerListener(this, sSensor,
                                            SensorManager.SENSOR_DELAY_GAME);
            sSensorManager.registerListener(this, sGyroscope,
                                            SensorManager.SENSOR_DELAY_GAME);
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        if (deviceSupported()) {
            sSensorManager.unregisterListener(this);
        }
    }


    private boolean deviceSupported() {
        return (null != sSensorManager && null != sSensor && null != sGyroscope);
    }


    private float smooth(float input, float output) {
        float alpha = 0.2f;
        DecimalFormat df = new DecimalFormat("0.000");
        return Float.valueOf(df.format(output + alpha * (input - output)));
    }


    private float smoothGyro(float input, float output) {
        float alpha = 0.2f;
        return (int) (output + alpha * (input - output));
    }


    private void findMidFrame(int endOfFrame) {
        midOfFrame = (endOfFrame / 2);

    }


    private float getTweakFactor() {
        return 1.5f;
    }

}
