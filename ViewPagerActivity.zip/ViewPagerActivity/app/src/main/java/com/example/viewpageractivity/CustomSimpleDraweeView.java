package com.example.viewpageractivity;

import android.content.Context;
import android.util.AttributeSet;

import com.facebook.drawee.view.SimpleDraweeView;

public class CustomSimpleDraweeView extends SimpleDraweeView {
    public static final float ASPECT_RATIO = 3 / 7;                                              //Aspect Ratio for Screen


    public CustomSimpleDraweeView(Context context) {
        super(context);
    }

    public CustomSimpleDraweeView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(getMeasuredWidth(), (int) (getMeasuredHeight() / ASPECT_RATIO));
    }

}
